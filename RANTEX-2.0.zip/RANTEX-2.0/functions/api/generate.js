const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

export async function onRequestPost({ request, env }) {
  if (!env.GEMINI_API_KEY) return json({ error: "AI generation is not configured. Add GEMINI_API_KEY as an encrypted Pages secret." }, 503);
  let body;
  try { body = await request.json(); } catch { return json({ error: "Request body must be valid JSON." }, 400); }
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const aspectRatio = ["16:9", "9:16", "1:1"].includes(body.aspectRatio) ? body.aspectRatio : "16:9";
  const style = typeof body.style === "string" ? body.style.slice(0, 60) : "Futuristic neon";
  if (prompt.length < 8 || prompt.length > 700) return json({ error: "Prompt must be between 8 and 700 characters." }, 400);

  // Configure GEMINI_MODEL as a Pages variable if you want to change models.
  const model = env.GEMINI_MODEL || "gemini-3.1-flash-image";
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const instruction = `Create one original, high-quality wallpaper image. Visual direction: ${style}. Aspect ratio: ${aspectRatio}. User concept: ${prompt}. No watermark, no logos, no text, polished composition suitable as a device wallpaper.`;
  try {
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        contents: [{ parts: [{ text: instruction }] }],
        generationConfig: { responseModalities: ["IMAGE", "TEXT"] }
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const message = result?.error?.message || `Image provider returned ${upstream.status}`;
      return json({ error: message }, upstream.status === 429 ? 429 : 502);
    }
    const parts = result?.candidates?.[0]?.content?.parts || [];
    const imagePart = parts.find(p => p.inlineData?.data && p.inlineData?.mimeType?.startsWith("image/"));
    if (!imagePart) return json({ error: "No image was returned. Check that your selected model supports image output and that your API project has access." }, 502);
    return json({ image: `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}` });
  } catch (error) {
    return json({ error: "Could not reach the image provider. Please try again later." }, 502);
  }
}
