$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Public = Join-Path $Root 'public'
Write-Host 'RANTEX 2.0 - local preview' -ForegroundColor Magenta
Write-Host 'Starting static preview at http://localhost:5500' -ForegroundColor Cyan
Write-Host 'Press Ctrl+C to stop.' -ForegroundColor Yellow
if (Get-Command py -ErrorAction SilentlyContinue) {
  py -m http.server 5500 --directory $Public
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
  python -m http.server 5500 --directory $Public
} else {
  Write-Host 'Python was not found. Install Python 3 or use the Cloudflare local preview command in README.' -ForegroundColor Red
  exit 1
}
