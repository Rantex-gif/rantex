# RANTEX 2.0 — AI Wallpaper Universe

A responsive static wallpaper gallery plus a Cloudflare Pages Function that securely calls the Google Gemini image-generation API. The gallery, search, category filters, favorites and local activity counters work without an API key. AI image generation requires a Google AI Studio API key and a model/account with image output access.

## Project structure

```text
RANTEX-2.0/
├── public/
│   └── index.html              # Complete responsive frontend
├── functions/
│   └── api/
│       └── generate.js         # Server-side Gemini image API proxy
├── Start-RANTEX.ps1            # Windows local static preview
├── .gitignore
├── wrangler.toml
└── README.md
```

## 1. Run the frontend on Windows

1. Extract the ZIP.
2. Open PowerShell in the extracted `RANTEX-2.0` folder.
3. Run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\Start-RANTEX.ps1
```

4. Visit `http://localhost:5500`.

This static preview runs the gallery only. The `/api/generate` endpoint requires Cloudflare Pages Functions; use the next section for a full local preview.

## 2. Full local preview, including the AI function

Install Node.js LTS, then in PowerShell from the project folder:

```powershell
npm install --save-dev wrangler
npx wrangler pages dev public
```

For local AI testing, create a `.dev.vars` file in the project root (never commit it):

```dotenv
GEMINI_API_KEY="paste-your-private-key-here"
GEMINI_MODEL="gemini-3.1-flash-image"
```

Restart the local Pages preview after changing secrets. If the chosen model is unavailable to your Google AI Studio project, choose an image-generation model currently enabled for your account and set `GEMINI_MODEL` accordingly.

## 3. Get an API key (optional; required only for AI generation)

1. Visit https://aistudio.google.com/app/apikey
2. Create an API key in your Google AI Studio project.
3. Review current model availability, quotas, data-use terms and pricing at https://ai.google.dev/gemini-api/docs/pricing
4. Do not paste the key into `public/index.html`, frontend JavaScript, GitHub, screenshots, or a public repository.

The current default model is `gemini-3.1-flash-image`. Image generation may not have a free tier. Google can change model names, access, quota and pricing; check the official pricing page before enabling it for visitors. A free hosting plan does not make paid AI inference free.

## 4. Deploy on Cloudflare Pages (recommended)

Use Git integration because this project includes a Pages Function. Do not deploy only the `public` folder: the root-level `functions` directory is required for `/api/generate`.

1. Create a GitHub account at https://github.com/ if you do not have one.
2. Create a new repository, e.g. `rantex`.
3. Upload the contents of this project to the repository root. Keep `public/` and `functions/` at the root.
4. Sign in to https://dash.cloudflare.com/.
5. Open **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
6. Select your `rantex` repository.
7. Set the build command to `exit 0` and the build output directory to `public`.
8. Deploy. Cloudflare will provide a `*.pages.dev` address.
9. In your Pages project, open **Settings → Variables and Secrets**. Add `GEMINI_API_KEY` as an encrypted secret. Optionally add `GEMINI_MODEL` as a variable. Save and redeploy.
10. Test the gallery and `/api/generate` from the live site.

Official docs:
- Static HTML on Pages: https://developers.cloudflare.com/pages/framework-guides/deploy-anything/
- Pages Functions: https://developers.cloudflare.com/pages/functions/get-started/
- Environment variables and secrets: https://developers.cloudflare.com/pages/functions/bindings/

## 5. Free hosting and realistic limits

- Cloudflare Pages offers a free tier for static hosting with published plan limits. Check current limits: https://developers.cloudflare.com/pages/platform/limits/
- GitHub repository hosting and Cloudflare static hosting can be used without buying a domain.
- The `*.pages.dev` address is free. A custom `.com` domain normally costs money.
- Gemini image-generation API usage is separate from hosting and may be paid. The project does not promise unlimited free generation.
- Unsplash sample images are remote demo images. For a public commercial wallpaper library, replace them with images you own, have permission to distribute, or that carry suitable licenses. Review each image's license and download terms.

## 6. What is demo-only and what is production-ready

Working in this starter:
- Responsive wallpaper gallery, search, category filters and sorting.
- Favorites saved in browser localStorage.
- Download/open actions for gallery images.
- AI prompt form and server-side Gemini API request function.
- Local browser activity counters.

Not included yet:
- Real user accounts or cross-device favorites.
- A secured multi-user admin dashboard.
- Central database, image storage/CDN, moderation queue or server analytics.
- Production rate limiting, abuse prevention, payment system or user upload moderation.

Before opening AI generation to the public, add server-side rate limiting (for example Cloudflare Turnstile plus a rate-limit store/Worker or Durable Object), usage budgets, content moderation, logging with privacy controls and a clear privacy policy. Do not treat browser-side counters as security controls.

## 7. PowerShell helper

`Start-RANTEX.ps1` runs a simple local static preview using Python 3. For the full API integration, use `npx wrangler pages dev public` as described above.
